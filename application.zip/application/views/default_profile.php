<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
    <base href="<?php echo base_url(); ?>"></base>
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href=" assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href=" assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href=" assets/css/headers/header-v6.css">    
    <link rel="stylesheet" href=" assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href=" assets/plugins/animate.css">
    <link rel="stylesheet" href=" assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href=" assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href=" assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href=" assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href=" assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href=" assets/plugins/image-hover/css/img-hover.css">

    <link rel="stylesheet" href=" assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href=" assets/css/custom.css">
    
</head> 

<body class="header-fixed header-fixed-space" data-spy="scroll" data-target=".onefixed">    

<div class="wrapper">
    <div class="header-v6 header-classic-white header-sticky">

        <!-- Navbar -->
        <nav class="navbar navbar-default mega-menu onefixed" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img id="logo-header" class="hidden-xs" src=" assets/img/logo2.png" alt="Logo">
                        <img id="logo-header" class="visible-xs" src=" assets/img/logo-xs.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#intro" class="page-scroll">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#services" class="page-scroll" >
                                    Our Services
                                </a>
                            </li>                    
                            
                            <li>
                                <a href="#venues" class="page-scroll" >
                                    Venues
                                </a>
                            </li>

                            <li>
                                <a href="#" class="page-scroll blink_text" style="color:red">
                                    Plan your Event Now
                                </a> 
                            </li>  

                            <li>
                                <a href="#about" class="page-scroll">
                                    About Us
                                </a>
                            </li>                    
                           

                            <li>
                                <a href="#foot" class="page-scroll">
                                    Contact Us
                                </a>
                            </li>        

                            <li>
                                <a href="#" class="page-scroll">
                                    Blog
                                </a>
                            </li>                         


                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </nav>            
        <!-- End Navbar -->
    </div>
    

    <div class="container">
     <div class="row">
         <div class="col-sm-8">
          <div class="profile-body">
            <div class="shadow-wrapper">
            <div class="profile-bio tag-box tag-box-v2 box-shadow shadow-effect-1">
                <div class="row">
                    <div class="col-sm-5">
                        <img class="img-responsive md-margin-bottom-10" src="assets/img/team/img1-md.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                        <h2><?php echo $info->name ;?></h2>
                        <strong><?php echo $info->category ;?></strong>
                        <hr>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eget massa nec turpis congue bibendum. Integer nulla felis, porta suscipit nulla et, dignissim commodo nunc. Morbi a semper nulla.</p>
                        <p><br/>Proin mauris odio, pharetra quis ligula non, vulputate vehicula quam. Nunc in libero vitae nunc ultricies tincidunt ut sed leo.<br> Sed luctus dui ut congue consequat.</p>
                    </div>
                </div>    
            </div>
            </div>
           </div>
          </div>

         <div class="col-xs-12 col-sm-4">
            <div class="panel panel-red margin-bottom-10">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Request Memorable Shaadi Special price</h3>
                </div>        
                <div class="panel-body"> 
                <form class="margin-bottom-10" method="post" role="form">
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" placeholder="Enter Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" id="email" placeholder="Enter Email" required>
                    </div>                    
                    <div class="form-group">
                        <input type="text" class="form-control" id="phone" placeholder="Enter Phone" required>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" id="message" placeholder="Enter message" required></textarea>
                    </div>
                    <button type="submit" class="btn-u btn-u-red" id="submit">Submit</button>
                </form>   
                    <div class="form-group" id="result" style="display:none;">
                         Thank you for contacting us. You will receive info shortly.
                    </div>                          
                </div>
            </div> 
         </div>
     </div>

      <div class="row">
       <div class="col xs-12 col-sm-8">  
         <div class="shadow-wrapper">
            <div class="tag-box tag-box-v2 box-shadow shadow-effect-1">
                <h2>PHOTOS</h2>
                <div class="row  margin-bottom-30 margin-top-20">
                    <div class="col-sm-4 sm-margin-bottom-30">
                        <a href="images/<?php echo $info->category.'/'.$info->name?>/img1.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 1">
                            <span><img class="img-responsive" src="images/<?php echo $info->category.'/'.$info->name?>/img1.jpg" alt=""></span>
                        </a>
                    </div>
                    <div class="col-sm-4 sm-margin-bottom-30">
                        <a href="assets/img/main/<?php echo $info->category.'/'.$info->name?>/img2.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 2">
                            <span><img class="img-responsive" src=" assets/img/main/<?php echo $info->category.'/'.$info->name?>/img2.jpg" alt=""></span>
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a href="assets/img/main/<?php echo $info->category.'/'.$info->name?>/img3.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 3">
                            <span><img class="img-responsive" src=" assets/img/main/<?php echo $info->category.'/'.$info->name?>/img3.jpg" alt=""></span>
                        </a>
                    </div>
                </div>   
                <div class="row  margin-bottom-30">
                    <div class="col-xs-4 col-sm-4 sm-margin-bottom-30">
                        <a href="assets/img/main/img1.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 1">
                            <span><img class="img-responsive" src="assets/img/main/img1.jpg" alt=""></span>
                        </a>
                    </div>
                    <div class="col-xs-4 col-sm-4 sm-margin-bottom-30">
                        <a href="assets/img/main/img7.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 2">
                            <span><img class="img-responsive" src="assets/img/main/img7.jpg" alt=""></span>
                        </a>
                    </div>
                    <div class="col-xs-4 col-sm-4">
                        <a href="assets/img/main/img5.jpg" rel="gallery1" class="fancybox img-hover-v1" title="Image 3">
                            <span><img class="img-responsive" src="assets/img/main/img5.jpg" alt=""></span>
                        </a>
                    </div>
                </div>                            
            </div>
        </div>
       </div> 
      </div>

      <div class="row">
       <div class="col-xs-12 col-sm-8">  
         <div class="shadow-wrapper">
            <div class="tag-box tag-box-v2 box-shadow shadow-effect-1">
              <h2>ABOUT US</h2>
               <div class="row">
                 <div class="col-xs-4 col-sm-4">
                   <h5><b>Name:</b></h5>
                   <h5><b>Address:</b></h5>
 
                 </div>
                 <div class="col-xs-8 col-sm-6 ">
                   <h5><?php echo $info->name ; ?></h5>
                   <h5><?php echo $info->address ; ?></h5>

                 </div>                 
                </div> 
            </div>          
        </div>
       </div>        
      </div>

    </div>
   
    <div class="footer-v1">
        <div class="footer">
            <div class="container">
                <div class="row">
                    <!-- About -->
                    <div class="col-md-3 md-margin-bottom-40">
                        <a href="index.html"><img id="logo-footer" class="footer-logo" src="assets/img/logo2-default.png" alt=""></a>
                        <p>About Unify dolor sit amet, consectetur adipiscing elit. Maecenas eget nisl id libero tincidunt sodales.</p>
                        <p>Duis eleifend fermentum ante ut aliquam. Cras mi risus, dignissim sed adipiscing ut, placerat non arcu.</p>    
                    </div><!--/col-md-3-->
                    <!-- End About -->

                    <!-- Latest -->
                    <div class="col-md-3 md-margin-bottom-40">
                        <div class="posts">
                            <div class="headline"><h2>Latest Posts</h2></div>
                            <ul class="list-unstyled latest-list">
                                <li>
                                    <a href="#">Incredible content</a>
                                    <small>May 8, 2014</small>
                                </li>
                                <li>
                                    <a href="#">Best shoots</a>
                                    <small>June 23, 2014</small>
                                </li>
                                <li>
                                    <a href="#">New Terms and Conditions</a>
                                    <small>September 15, 2014</small>
                                </li>
                            </ul>
                        </div>
                    </div><!--/col-md-3-->  
                    <!-- End Latest --> 
                    
                    <!-- Link List -->
                    <div class="col-md-3 md-margin-bottom-40">
                        <div class="headline"><h2>Useful Links</h2></div>
                        <ul class="list-unstyled link-list">
                            <li><a href="#">About us</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Portfolio</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Latest jobs</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Community</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Contact us</a><i class="fa fa-angle-right"></i></li>
                        </ul>
                    </div><!--/col-md-3-->
                    <!-- End Link List -->                    

                    <!-- Address -->
                    <div class="col-md-3 map-img md-margin-bottom-40">
                        <div class="headline"><h2>Contact Us</h2></div>                         
                        <address class="md-margin-bottom-40">
                            25, Lorem Lis Street, Orange <br />
                            California, US <br />
                            Phone: 800 123 3456 <br />
                            Fax: 800 123 3456 <br />
                            Email: <a href="mailto:info@anybiz.com" class="">info@anybiz.com</a>
                        </address>
                    </div><!--/col-md-3-->
                    <!-- End Address -->
                </div>
            </div> 
        </div><!--/footer-->

        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">                     
                        <p>
                            2015 &copy; All Rights Reserved.
                           <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
                        </p>
                    </div>

                    <!-- Social Links -->
                    <div class="col-md-6">
                        <ul class="footer-socials list-inline">
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Skype">
                                    <i class="fa fa-skype"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Linkedin">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Pinterest">
                                    <i class="fa fa-pinterest"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Dribbble">
                                    <i class="fa fa-dribbble"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- End Social Links -->
                </div>
            </div> 
        </div><!--/copyright-->
    </div>    
</div>  

<!-- JS Global Compulsory -->           
<script type="text/javascript" src="assets/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery/jquery-migrate.min.js"></script>
<script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script type="text/javascript" src="assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src="assets/plugins/smoothScroll.js"></script>
<script type="text/javascript" src="assets/plugins/jquery.easing.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery.parallax.js"></script>
<script type="text/javascript" src="assets/plugins/flexslider/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="assets/plugins/image-hover/js/touch.js"></script>
<script type="text/javascript" src="assets/plugins/image-hover/js/modernizr.js"></script>
<!-- JS Customization -->
<script type="text/javascript" src="assets/js/custom.js"></script>
<!-- JS Page Level -->           
<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/plugins/fancy-box.js"></script>
<script type="text/javascript" src="assets/js/plugins/revolution-slider.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        FancyBox.initFancybox();
        RevolutionSlider.initRSfullWidth();
    });
</script>
<script type="text/javascript">
  $(document).ready(function(){
  $('form').submit(function(e){
    e.preventDefault();
    var name =$("input#name").val();
    var email =$("input#email").val();
    var phone =$("input#phone").val();
    var message =$("textarea#message").val();

    jQuery.ajax({
     type:"POST",
     url:"Site/query",
     dataType:'json',
     data:{name1: name,email1: email,phone1: phone,msg: message},
     
     success: function(res){
       
     if(res)
      {
         jQuery("div#result").show();
      }  

      else{
        alert("error");
      }

     }

    }); 

   });   
  });  
</script>
</body>
<html>