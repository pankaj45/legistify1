<?php
$msg=$this->uri->segment(3);

if($msg == "success")
{
  echo '<script>alert("Done")</script>';
}
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
    <base href="<?php echo base_url(); ?>"></base>
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href=" assets/css/headers/header-v6.css">    
    <link rel="stylesheet" href=" assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="assets/plugins/animate.css">
    <link rel="stylesheet" href="assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href="assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href="assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href="assets/plugins/image-hover/css/img-hover.css">
    <link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css">
    <link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css">
    <link rel="stylesheet" href="assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href="assets/css/custom.css">
   
</head> 

<body class="header-fixed header-fixed-space" data-spy="scroll" data-target=".onefixed">    

<div class="wrapper">
    <div class="header-v6 header-classic-white header-sticky">

        <!-- Navbar -->
        <nav class="navbar navbar-default mega-menu onefixed" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img id="logo-header" class="hidden-xs" src=" assets/img/logo2.png" alt="Logo">
                        <img id="logo-header" class="visible-xs" src=" assets/img/logo-xs.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#intro" class="page-scroll">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#services" class="page-scroll" >
                                    Our Services
                                </a>
                            </li>                    
                            
                            <li>
                                <a href="#venues" class="page-scroll" >
                                    Venues
                                </a>
                            </li>

                            <li>
                                <a href="#" class="page-scroll blink_text" style="color:red">
                                    Plan your Event Now
                                </a> 
                            </li>  

                            <li>
                                <a href="#about" class="page-scroll">
                                    About Us
                                </a>
                            </li>                    
                           

                            <li>
                                <a href="#foot" class="page-scroll">
                                    Contact Us
                                </a>
                            </li>        

                            <li>
                                <a href="#" class="page-scroll">
                                    Blog
                                </a>
                            </li>                         


                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </nav>            
        <!-- End Navbar -->
    </div>
    
    <div class="col-md-6 col-md-offset-3">
                    <div class="panel panel-red margin-bottom-40">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="fa fa-tasks"></i>Vendor Registration Form </h3>
                            <h5><?php if(isset($name)) echo $name ;?></h5>
                        </div>
                        <div class="panel-body">                                                      
                            <form class="margin-bottom-40" method="post" enctype="multipart/form-data" action="Site/admin"  role="form">
                              
                                <div class="form-group">
                                    <?php echo form_error('name'); ?>
                                    <label for="name">Vendor/Brand Name</label> 
                                    <input type="text" name="name" class="form-control" value="<?php echo set_value('name'); ?>" id="name" placeholder="Enter Name" required>
                                </div>
                              
                                <div class="form-group">
                                    <label for="category">Category</label>
                                    <select name="category" id="category" class="form-control">
                                     <option value="venue">Venue</option>
                                     <option value="caterer">Caterer</option>
                                     <option value="band">Wedding Band</option>
                                     <option value="decor">Decorators</option>
                                     <option value="entertainment">Entertainment</option>
                                     <option value="photography">Photography</option>
                                     <option value="gifts">Gift Vendors</option>
                                     <option value="cards">Invitation Cards</option>
                                     <option value="coins">Gold/Silver Coins</option>
                                    </select>
                                </div>
                              
                                <div class="form-group">
                                     <label for="city">City</label> 
                                     <select name="city" class="form-control">
                                      <option value="delhi">Delhi</option>
                                      <option value="goa">Goa</option>
                                      <option value="jaipur">Jaipur</option>   
                                     </select>
                                 </div> 
                                 
                            <!--     <div class="form-group">
                                     <label for="area">Area</label> 
                                     <select name="area" class="form-control">
                                       <option value="north">North</option>   
                                       <option value="south">South</option>
                                       <option value="east">East</option>
                                       <option value="west">West</option>   
                                     </select>
                                 </div>    -->                

                                 <div class="form-group">
                                   <?php echo form_error('address'); ?>
                                   <label for="address">Address</label>
                                   <input type="text" name="address" class="form-control" value="<?php echo set_value('address'); ?>"  placeholder="Enter Address" required> 
                                 </div>              

                                 <div class="form-group">
                                   <label for="location">Location</label>
                                   <input type="text" name="location" class="form-control" value="<?php echo set_value('location'); ?>" placeholder="Enter Location" required> 
                                 </div>
                                 
                                 <div class="form-group">
                                   <label for="contactp">Contact Person</label>
                                   <input type="text" name="contactp" class="form-control" value="<?php echo set_value('contactp'); ?>" placeholder="Enter Name" required> 
                                 </div> 
 

                                 <div class="form-group">
                                   <label for="contact">Contact No.</label>
                                   <input type="text" name="contact" class="form-control" value="<?php echo set_value('contact'); ?>" placeholder="Enter Contact No." required> 
                                 </div> 

                                 <div class="form-group">
                                   <label for="email">Email Id</label>
                                   <input type="email" name="email" class="form-control" value="<?php echo set_value('email'); ?>" placeholder="Enter Email Id"> 
                                 </div>        

                                 <div class="form-group">
                                   <label for="no">No. of Lawns</label>
                                   <input type="number" id="no" name="no" class="form-control" onchange="addFields()" min="0" max="5" 
                                   value="0" placeholder="No. of Lawns"  required> 
                                 </div>                                 

                                 <div class="form-group" id="lawn">
                                 </div>
                                 
                                 <div class="form-group">
                                   <label for="no1">No. of Banquets</label>
                                   <input type="number" id="no1" name="no1" class="form-control" onchange="addFields()" min="0" max="5" 
                                   value="0" placeholder="No. of Banquets"  required> 
                                 </div> 

                                 <div class="form-group" id="banquet">
                                 </div>

                                <div class="form-group">
                                    <label for="description">Short Description</label>
                                    <textarea rows="5" name="description" class="form-control" value="<?php echo set_value('description'); ?>" required></textarea>
                                </div>

                                
                                                                                    
                        <!--      <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                   </div> -->
                                  
                                  <button type="submit" class="btn-u btn-u-red">Submit</button>
                                 
                            </form>
                        </div>
                    </div>
                

    </div>   

    





</div><!--/wrapper-->

<!-- JS Global Compulsory -->           
<script type="text/javascript" src=" assets/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery/jquery-migrate.min.js"></script>
<script type="text/javascript" src=" assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script type="text/javascript" src=" assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src=" assets/plugins/smoothScroll.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.easing.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.parallax.js"></script>
<script type="text/javascript" src=" assets/plugins/flexslider/jquery.flexslider-min.js"></script>
<script type="text/javascript" src=" assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/touch.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/modernizr.js"></script>
<!-- JS Customization -->
<script type="text/javascript" src=" assets/js/custom.js"></script>
<!-- JS Page Level -->           
<script type="text/javascript" src=" assets/js/app.js"></script>
<script type="text/javascript" src=" assets/js/plugins/fancy-box.js"></script>
<script type="text/javascript" src=" assets/js/plugins/revolution-slider.js"></script>

<script src="assets/plugins/scroll/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll/js/scrolling-nav.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        FancyBox.initFancybox();
        RevolutionSlider.initRSfullWidth();
    });
</script>

   <script type="text/javascript">
          function addFields(){
            // Number of inputs to create
            var number = document.getElementById("no").value;
            // Container <div> where dynamic content will be placed
            var number1 = document.getElementById("no1").value;
            var container = document.getElementById("lawn");
            var container1 = document.getElementById("banquet");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }

            while (container1.hasChildNodes()) {
                container1.removeChild(container1.lastChild);
            }

            if(number > 0)
            {  
                for (i=0;i<number;i++){
                    
                    var item="Lawn "+(i+1)+"-Capacity";
                    var lawnlabel = document.createElement("label");
                    lawnlabel.setAttribute("for",item);
                    lawnlabel.innerHTML=item;
                    // Create an <input> element, set its type and name attributes
                    var input = document.createElement("input");
                    input.type = "text";
                    input.name = item;
                    input.className = "form-control";
                    container.appendChild(lawnlabel);
                    container.appendChild(input);
                }
            }
            
           if(number1 > 0)
           {
                for (j=0;j<number1;j++){
                    
                    var item1="Banquet "+(j+1)+"-Capacity";
                    var lawnlabel1 = document.createElement("label");
                    lawnlabel1.setAttribute("for",item1);
                    lawnlabel1.innerHTML=item1;
                    // Create an <input> element, set its type and name attributes
                    var input1 = document.createElement("input");
                    input1.type = "text";
                    input1.name = item1;
                    input1.className = "form-control";
                    container1.appendChild(lawnlabel1);
                    container1.appendChild(input1);
                }

           } 

        } 

   </script>

</body>
</html>