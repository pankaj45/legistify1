<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
    <base href="<?php echo base_url(); ?>"></base>
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href=" assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href=" assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href=" assets/css/headers/header-v6.css">    
    <link rel="stylesheet" href=" assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href=" assets/plugins/animate.css">
    <link rel="stylesheet" href=" assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href=" assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href=" assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href=" assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href=" assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href=" assets/plugins/image-hover/css/img-hover.css">

    <link rel="stylesheet" href=" assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href=" assets/css/custom.css">
    
</head>	

<body class="header-fixed header-fixed-space" data-spy="scroll" data-target=".onefixed">    

<div class="wrapper">
    <div class="header-v6 header-classic-white header-sticky">

        <!-- Navbar -->
        <nav class="navbar navbar-default mega-menu onefixed" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="">
                        <img id="logo-header" class="hidden-xs" src="assets/img/logo2.png" alt="Logo">
                        <img id="logo-header" class="visible-xs" src="assets/img/logo-xs.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#intro" class="page-scroll">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#services" class="page-scroll" >
                                    Our Services
                                </a>
                            </li>                    
                            
                            <li>
                                <a href="#venues" class="page-scroll" >
                                    Venues
                                </a>
                            </li>

                            <li>
                                <a href="#" class="page-scroll blink_text" style="color:red" data-toggle="modal" 
      data-target="#myModal">
                                    Plan your Event Now
                                </a> 
                            </li>  

                            <li>
                                <a href="#about" class="page-scroll">
                                    About Us
                                </a>
                            </li>                    
                           

                            <li>
                                <a href="#foot" class="page-scroll">
                                    Contact Us
                                </a>
                            </li>        

                            <li>
                                <a href="#" class="page-scroll">
                                    Blog
                                </a>
                            </li>                         


                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </nav>            
        <!-- End Navbar -->
    </div>