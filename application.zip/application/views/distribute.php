

<html>

<head>

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>

function getpage(services)
{
document.getElementById('select').innerHTML  = "loading areas.........";
var url='<?php echo base_url()."Site/";?>';
//        e.preventDefault();
      $('#select').load( url+services+"_select");
	
}



</script>
</head>
<body>
<?php
$flag=1;
$service_array=$this->session->userdata('services');

foreach($service_array as $service)
	{		
			if(!empty($this->session->userdata($service)))
			{$text=$this->session->userdata($service);
					}
		else
			{$text=$service;
			$flag=-999;}
	//	echo "<a href='" .$service."_select.php' class='button'>".$text. "</a><br>";
		echo "<button onclick='getpage(".'"'.$service.'"'.")' >".$text."</button>";
		}
	
	if(isset($_POST['submit']))
	
	
	if(isset($_POST["submit"]))
		{
		
		}
	else
		echo "bye";

	?>
	
<div id="select">

</div>

</body>
</html>