

    <div class="container margin-bottom-10"> 
        <div class="col-sm-6 col-sm-offset-3 animated fadeInLeft">
            <div class="input-group" style="margin-top:10px; margin-bottom:10px">
                <input type="text" class="form-control" placeholder="Search your vendor">
                <span class="input-group-btn">
                    <button class="btn-u btn-u-md" type="button"><i class="fa fa-search"></i></button>
                </span>
            </div>    
        </div>
    </div> 

    <div class="container">
      <div class="row">
       <div class="col-xs-12">
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/venue">Venues</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/caterer" >Catering</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/decor">Decorators</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/photography">Photographers</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/band">Wedding Bands</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/tent">Tent vendors</a> 
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/cards">Invitation Cards</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/logistics">Logistics</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/venue">Icon Button</a>
        <a class="btn-u btn-u-red rounded-3x margin-bottom-10" type="button" href="Site/gallery/venue">Icon Button</a>
       </div>        
      </div>                  
    </div> 


    <div class="container content-sm">  
      <div class="headline text-center"><h2><h2><?php echo ucfirst($type);?></h2></div>     
        <div class="row featured-blog margin-bottom-10">

            <?php
             $i=1;
            foreach ($query_result->result() as $row) {
                echo '<div class="col-sm-3" >
                <div class="featured-img">
                    <img class="img-responsive margin-bottom-20" src="images/'.$type.'/'.str_replace(" ","",$row->name).'/img1.png" alt="">
                    <a href="Site/'.$type.'_display/'.$row->vendor_no.'"><i class="rounded-x fa fa-link"></i></a>
                </div>

                <h2><a class="color-dark" href="Site/'.$type.'_display/'.$row->vendor_no.'">'.$row->name.'</a></h2>
                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum.</p>
            </div>
            ';
                if(($i%4) == 0)
                {
                    echo '</div><div class="row featured-blog margin-bottom-10">' ;
                }
              $i++;  
            }?>
            

        </div><!--/end row-->
    </div>
