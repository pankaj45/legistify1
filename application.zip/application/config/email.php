<?php

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.gmail.com'; 
$config['smtp_port'] = '465';
$config['smtp_user'] = 'pankaj.arora1994@gmail.com'; 
$config['smtp_pass'] = '9818614415pP'; 
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n"; 

?>