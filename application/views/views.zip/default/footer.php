    <!-- Footer -->
    <footer >
        <div class="myfooter">
        <div class="footer-section container content-section text-left" >
            <div class="row" style="padding-left:0px;margin-top:-50px">
                <div class="col-md-4 vcenter" >
                    <h2 style="text-align:left;margin-bottom:0px">legistify</h2>
                    <!-- <h4>Contact Us</h4> -->
                    <!-- <img src="img/bg.png"  width="80px" height="2px" style="margin-top:-30px;"> -->
                    <ul style="list-style-type:none; text-decoration: none;display:inline">
                        <!-- <li><b>Address: </b></li> -->
                        <li> B-37 Ground floor, Polyplex Tower, Noida- Sector 1</li>
                        <!-- <li><br/></li> -->
                        <li><b>Phone:</b> +919024456014</li>
                        <!-- <li><br/></li> -->
                        <li><b>Email:</b> contact@legistify.com</li>
                        <li><br/></li>
                    </ul>
                    <button href="#" class="btn btn-social azm-facebook" ><i class="fa fa-facebook"></i></button>
                    <button href="#" class="btn btn-social azm-google-plus"><i class="fa fa-google-plus"></i></button>
                    <button href="#" class="btn btn-social azm-twitter"><i class="fa fa-twitter"></i></button>
                    <button href="#" class="btn btn-social azm-linkedin"><i class="fa fa-linkedin"></i></button>
                    <button href="#" class="btn btn-social azm-slideshare"><i class="fa fa-slideshare"></i></button>
                <br/>
                <br/>
                <br/>
                <br/>

                </div>
                <div class="col-md-1 " style="text-align:left;">
                <br/>
                <br/>
                <br/>
                <br/>
                
                </div>
                <div class="col-md-2 col-sm-3 col-xs-5" style="text-align:left;">
                    <h4>Quick Links</h4>
                    <img src="assets/img/bg.png"  width="50px" height="2px" style="margin-top:-30px;">
                    <ul style="list-style-type:none; text-decoration: none;display:inline">
                        <li><a href="Legal/about">About</a></li>
                        <li><a href="Legal/team">Team</a></li>
                        <li><a href="Legal/careers">Careers</a></li>
                        <li><a  href="Legal/categories">Document</a></li>
                        <li><a  href="Legal/search">Research</a></li>
                        <li><a  href="#">Pricing</a></li>
                        <li><a  href="Legal/sitemap">Site Map</a></li>
                        <li><br/></li>
                    </ul>
                </div>

                <div class="col-md-3 col-sm-5 col-xs-7" style="text-align:left; ">
                    <h4>Most Popular</h4>
                    <div class="col-xs-12" style="padding-left:0px;height:2px">
                    <img src="assets/img/bg.png"  width="50px" height="2px" style="margin-top:-30px;">
                    </div>
                    <div class="col-xs-6" style="padding-left:0px">
                      <ul style="list-style-type:none; text-decoration: none;display:inline">
                        <li><a href="Legal/document">Employment Contract</a></li>
                        <li><a href="Legal/document">Trademark Assignment</a></li>
                        <li><a href="Legal/document">Copyright Assignment</a></li>
                        <li><a href="Legal/document">Non-Disclosure</a></li>
                        <li><a href="Legal/document">Power of attorney</a></li>
                        <li><a href="Legal/document">Lease</a></li>
                      </ul>                      
                    </div>
                    <div class="col-xs-6">
                    <ul style="list-style-type:none; text-decoration: none;display:inline">
                        <li><a href="Legal/document">Sale Deed</a></li>
                        <li><a href="Legal/document">Arbitration Agreement</a></li>
                        <li><a href="Legal/document">Will</a></li>
                        <li><a href="Legal/document">Graphic  designer agreement</a></li>
                        <li><a href="Legal/document">merchant agreement</a></li>
                      </ul>                      
                    </div>

                 </div>
                <div class="col-md-2 col-sm-4 col-xs-6" style="text-align:left; ">
                    <h4>Legal Topics</h4>
                    <img src="assets/img/bg.png"  width="50px" height="2px" style="margin-top:-30px;">
                </div>

            </div>  
            
            <HR WIDTH="200%" style="margin-left:-50%;border-color:#F2F2F2" >
            <div class="col-md-6" style="margin-left:0px; padding-left:0px;text-align:left;float:left;">
                <div class="col-xs-4 " style="margin-left:0px; padding-left:0px">
                    <p style="font-size:15px">Terms And Condition</p>
                </div>
                <div class="col-xs-4" style="margin-left:0px; padding-left:0px">
                    <p style="font-size:15px">Legal Disclaimer</p>
                </div>
                <div class="col-xs-4" style="margin-left:0px; padding-left:0px">
                    <p style="font-size:15px">Privacy Policy</p>
                </div>
            </div>
            <div class="col-md-6 alignCenterOnMobile" style="text-align:right;float:right">
                <p style="font-size:15px;margin-left:0px">&#169;&nbsp;Legistify 2015</p>
            <br/>
            </div>

        </div>
        </div>
    </footer>







    <!-- jQuery -->
     <script src="assets/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
     <script src="assets/js/bootstrap.min.js"></script>
    <!-- Plugin JavaScript -->
     <script src="assets/js/jquery.easing.min.js"></script>
    <!-- Custom Theme JavaScript -->
     <script src="assets/js/grayscale.js"></script>

     <script src="assets/js/services.js"></script>
     <script src="assets/js/search.js"></script>



</body>



</html>
