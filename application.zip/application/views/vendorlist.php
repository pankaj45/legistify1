<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
    <base href="<?php echo base_url(); ?>"></base>
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href=" assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href=" assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href=" assets/css/headers/header-v6.css">    
    <link rel="stylesheet" href=" assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href=" assets/plugins/animate.css">
    <link rel="stylesheet" href=" assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href=" assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href=" assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href=" assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href=" assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href=" assets/plugins/image-hover/css/img-hover.css">

    <link rel="stylesheet" href=" assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href=" assets/css/custom.css">
<style type="text/css">
.modal-body {
    max-height: calc(100vh - 212px);
    overflow-y: auto;
}   

#myModal {
   top:10%;
   bottom:10%;
   outline:none; 
}
</style>    
</head> 

<body class="header-fixed header-fixed-space" data-spy="scroll" data-target=".onefixed">    

<div class="wrapper">
    <div class="header-v6 header-classic-white header-sticky">

        <!-- Navbar -->
        <nav class="navbar navbar-default mega-menu onefixed" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img id="logo-header" class="hidden-xs" src=" assets/img/logo2.png" alt="Logo">
                        <img id="logo-header" class="visible-xs" src=" assets/img/logo-xs.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#intro" class="page-scroll">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#services" class="page-scroll" >
                                    Our Services
                                </a>
                            </li>                    
                            
                            <li>
                                <a href="#venues" class="page-scroll" >
                                    Venues
                                </a>
                            </li>

                            <li>
                                <a href="#" class="page-scroll blink_text" style="color:red" data-toggle="modal" 
      data-target="#myModal">
                                    Plan your Event Now
                                </a> 
                            </li>  

                            <li>
                                <a href="#about" class="page-scroll">
                                    About Us
                                </a>
                            </li>                    
                           

                            <li>
                                <a href="#foot" class="page-scroll">
                                    Contact Us
                                </a>
                            </li>        

                            <li>
                                <a href="#" class="page-scroll">
                                    Blog
                                </a>
                            </li>                         


                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </nav>            
        <!-- End Navbar -->
    </div>                    
                    

   <div class="container">
   <div class="headline text-center "><h2>List of vendors</h2></div>
    <div class="col-sm-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php 
                        $i=1; 
                       foreach($query_result->result() as $row) {
                        echo '<tr>
                            <td>'.$i.'</td>
                            <td>'.$row->name.'</td>
                            <td>'.$row->category.'</td>
                            <td><a class="btn btn-xs" href="Site/'.$row->category.'_display/'.$row->vendor_no.'" >View</a></td>                          
                        </tr>';
                        $i++;
                        } ?> 
                    </tbody>
                </table>                
    </div>
   </div> 

    <div class="footer-v1">
        <div class="footer">
            <div class="container content-sm">
                <div class="row">
                    <!-- About -->
                    <div class="col-md-4 md-margin-bottom-20">
                        <a href="index.html"><img id="logo-footer" class="footer-logo" src="assets/img/logo2.png" alt=""></a>
                        <p>About Unify dolor sit amet, consectetur adipiscing elit. Maecenas eget nisl id libero tincidunt sodales.</p>
                        <p>Duis eleifend fermentum ante ut aliquam. Cras mi risus, dignissim sed adipiscing ut, placerat non arcu.</p>    
                    </div><!--/col-md-3-->
                    <!-- End About -->

                    <!-- Latest -->
                    <div class="col-md-4 md-margin-bottom-20">
                        <div class="posts">
                            <div class="headline"><h2>Latest Posts</h2></div>
                            <ul class="list-unstyled latest-list">
                                <li>
                                    <a href="#">Incredible content</a>
                                    <small>May 8, 2014</small>
                                </li>
                                <li>
                                    <a href="#">Best shoots</a>
                                    <small>June 23, 2014</small>
                                </li>
                                <li>
                                    <a href="#">New Terms and Conditions</a>
                                    <small>September 15, 2014</small>
                                </li>
                            </ul>
                        </div>
                    </div><!--/col-md-3-->  
                    <!-- End Latest --> 
                    
                    <!-- Link List -->
                    <div class="col-md-4 md-margin-bottom-20">
                        <div class="headline"><h2>Useful Links</h2></div>
                        <ul class="list-unstyled link-list">
                            <li><a href="#">About us</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Portfolio</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Latest jobs</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Community</a><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Contact us</a><i class="fa fa-angle-right"></i></li>
                        </ul>
                    </div><!--/col-md-3-->
                    <!-- End Link List -->                    
                </div>
            </div> 
        </div><!--/footer-->

        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">                     
                        <p>
                            2015 &copy; All Rights Reserved.
                           <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
                        </p>
                    </div>

                    <!-- Social Links -->
                    <div class="col-md-6">
                        <ul class="footer-socials list-inline">
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Skype">
                                    <i class="fa fa-skype"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Linkedin">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Pinterest">
                                    <i class="fa fa-pinterest"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Dribbble">
                                    <i class="fa fa-dribbble"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- End Social Links -->
                </div>
            </div> 
        </div><!--/copyright-->


  
    

</div><!--/wrapper-->

<!-- JS Global Compulsory -->           
<script type="text/javascript" src=" assets/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery/jquery-migrate.min.js"></script>
<script type="text/javascript" src=" assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script type="text/javascript" src=" assets/plugins/smoothScroll.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.easing.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.parallax.js"></script>
<script type="text/javascript" src=" assets/plugins/flexslider/jquery.flexslider-min.js"></script>
<script type="text/javascript" src=" assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/touch.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/modernizr.js"></script>
<!-- JS Customization -->
<script type="text/javascript" src=" assets/js/custom.js"></script>
<!-- JS Page Level -->           
<script type="text/javascript" src=" assets/js/app.js"></script>
<script type="text/javascript" src=" assets/js/plugins/fancy-box.js"></script>
<script type="text/javascript" src=" assets/js/plugins/revolution-slider.js"></script>

<script src="assets/plugins/scroll/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll/js/scrolling-nav.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        FancyBox.initFancybox();
        RevolutionSlider.initRSfullWidth();
    });
</script>

</body>
</html> 
 
