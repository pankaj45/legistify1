

    <div class="container margin-bottom-10"> 
        <div class="col-sm-6 col-sm-offset-3 animated fadeInLeft">
            <div class="input-group" style="margin-top:10px; margin-bottom:10px">
                <input type="text" class="form-control" placeholder="Search your vendor">
                <span class="input-group-btn">
                    <button class="btn-u btn-u-md" type="button"><i class="fa fa-search"></i></button>
                </span>
            </div>    
        </div>
    </div>

    <div class="container content-sm">
        <div class="row margin-bottom-20">
            <div class="col-sm-12 ">
                <div class="funny-boxes funny-boxes-top-red">
                    <div class="row">
                        <div class="col-md-4 funny-boxes-img">
                            <img class="img-responsive" src="../assets/img/main/img12.jpg" alt="">
                            <ul class="list-unstyled">
                               <li><i class="fa-fw fa fa-map-marker"></i> New York, US</li>
                            </ul>
                        </div>
                        <div class="col-md-8">
                            <h2><a href="#">Praesentium Voluptatum</a></h2>

                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint</p>
                        </div>
                    </div>                            
                </div>
            </div>
         </div>   
         
         <div class="row margin-bottom-20">
            <div class="col-sm-12 ">
                <div class="funny-boxes funny-boxes-top-red">
                    <div class="row">
                        <div class="col-md-4 funny-boxes-img">
                            <img class="img-responsive" src="../assets/img/main/img12.jpg" alt="">
                            <ul class="list-unstyled">
                               <li><i class="fa-fw fa fa-map-marker"></i> New York, US</li>
                            </ul>
                        </div>
                        <div class="col-md-8">
                            <h2><a href="#">Praesentium Voluptatum</a></h2>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occa</p>
                        </div>
                    </div>                            
                </div>
            </div>            
        </div> 

          <div class="row margin-bottom-20">
            <div class="col-sm-12">
                <div class="funny-boxes funny-boxes-top-red">
                    <div class="row">
                        <div class="col-md-4 funny-boxes-img">
                            <img class="img-responsive" src="../assets/img/main/img16.jpg" alt="">
                            <ul class="list-unstyled">
                               <li><i class="fa-fw fa fa-map-marker"></i> New York, US</li>
                            </ul>
                        </div>
                        <div class="col-md-8">
                            <h2><a href="#">Oluptatum Box</a></h2>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecat.</p>
                        </div>
                    </div>                            
                </div>
            </div>
        </div>
    </div>


