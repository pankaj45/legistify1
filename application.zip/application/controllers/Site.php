
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller
{

    public function __construct()
       {
            parent::__construct();
            $this->load->library('session');
            $this->load->library('form_validation');      
            $this->form_validation->set_error_delimiters('<div class="alert alert-warning fade in">', '</div>');      
       }

// read directory
    public function _imgread($data)
    {
    	$this->load->helper('directory'); //load directory helper
		$dir = "images".$data; //  Your Path to folder
		$map = directory_map($dir);  
		//$this->load->view('image.php',$map);
		return $map;
    }


	public function index()
	{
		$this->load->view('default/header');
		$this->load->view('mshaadi');
		$this->load->view('default/footer');
	}

	public function demo()
	{
		$this->load->view('demo');
	}
	

    	
	
	///// Admin functions ////////////////////

	public function admin()
	{  
     
        
        //$this->form_validation->set_rules('name', 'Username', 'required|min_length[5]|max_length[15]');

        if($this->form_validation->run() == FALSE)
        {  
		$this->load->view('admin_home');
	    }
	    else
	    {   
	    	$data=array();
	    	$data['name']=$this->input->post('name');
	    	$data['category']=$this->input->post('category');
	    	$data['city']=$this->input->post('city');
	    	$data['address']=$this->input->post('address');
	    	$data['location']=$this->input->post('location');
	    	$data['contactp']=$this->input->post('contactp');
	    	$data['contact']=$this->input->post('contact');
	    	$data['email']=$this->input->post('email');
	    	$data['description']=$this->input->post('description');
             

              switch ($data['category']) {
              	case 'venue':
              		# code...
                    $this->load->view('venue_upload',$data);
              		break;
              	case 'caterer':
              		# code...
                    $this->load->view('caterer_upload',$data);
              		break;
              	case 'band':
              		# code...
              	    $this->load->view('band_upload',$data);
              		break;
              	case 'decor':
              		# code...
              	    $this->load->view('decor_upload',$data);
              		break;
              	case 'entertainment':
              		# code...
              	    $this->load->view('entertainment_upload',$data); 
              		break;              		              		              		              	
              	case 'photography':
              		# code...
              	    $this->load->view('photography_upload',$data); 
              		break; 
              	case 'gifts':
              		# code...
              	    $this->load->view('gifts_upload',$data); 
              		break; 
              	case 'cards':
              		# code...
                    $this->load->view('cards_upload',$data);
              		break;

              	case 'coins':
              		# code...
                    $this->load->view('coins_upload',$data);
              		break; 	               		              		
              }

	        }
	    
	}

	public function venue_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           

	    	$data['type']=$this->input->post('type');
	    	$data['accomodation']=$this->input->post('accom');
	    	$data['no_lawn']=$this->input->post('nol');
            $data['no_banquets']=$this->input->post('nob'); 
	    	
	    	if($data['no_lawn'] > 0)
	    	{  
              foreach ($this->input->post('Lawn') as $a ) {
              	$data['lawn_capacity'] .= $a.",";
              }

              foreach ($this->input->post('Rent') as $b ) {
              	$data['lawn_rent'] .= $b.",";
              }

	    	}

	    	if($data['no_banquets'] > 0)
	    	{
	    		foreach ($this->input->post('Banquet') as $c) {
	    		 $data['banquet_capacity'] .= $c.",";
	    		}
	    	}	
          
	    
	    	$data['price_plate']=$this->input->post('price');
	    	$data['outside_catering']=$this->input->post('oca');
	    	$data['outside_decor']=$this->input->post('oda');
	    	$data['parking']=$this->input->post('parking');
	    	$data['decor_charges']=$this->input->post('decor_charges');
	    	$data['dj_charges']=$this->input->post('dj_charges');
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	
	    	$data['img_folder']="images/venue/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Venue_model');
	    	  $result1 = $this->Venue_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('venue_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}


	public function caterer_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['basic_menu']=$this->input->post('basic_menu');
	    	$data['basic_menu_price']=$this->input->post('basic_menu_price');
	    	$data['premium_menu']=$this->input->post('premium_menu');
	    	$data['premium_menu_price']=$this->input->post('premium_menu_price');
	    	$data['platinum_menu']=$this->input->post('platinum_menu');
	    	$data['platinum_menu_price']=$this->input->post('platinum_menu_price');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/caterer/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Caterer_model');
	    	  $result1 = $this->Caterer_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('caterer_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}


	public function decor_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['package_details']=$this->input->post('basic_package');
	    	$data['package_min']=$this->input->post('package_price');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/decor/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Decor_model');
	    	  $result1 = $this->Decor_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('decor_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}


	public function gifts_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['gift_details']=$this->input->post('gift_details');
	    	$data['gift_price']=$this->input->post('gift_price');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/gifts/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Gifts_model');
	    	  $result1 = $this->Gifts_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('gifts_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}


	public function cards_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['cards_details']=$this->input->post('cards_details');
	    	$data['cards_price']=$this->input->post('cards_price');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/cards/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Cards_model');
	    	  $result1 = $this->Cards_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('cards_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}


	public function coins_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['coins_details']=$this->input->post('coins_details');
	    	$data['coins_price']=$this->input->post('coins_price');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/coins/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Coins_model');
	    	  $result1 = $this->Coins_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('coins_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}



	public function band_upload()
	{
     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();
             
	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['location']=$this->input->post('location');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');	        
            $vendor['description']=$this->input->post('description');
           
	    	$data['package_details']=$this->input->post('package_details');
	    	$data['package_price']=$this->input->post('package_price');
	    	$data['addons']=$this->input->post('addons');	 
	    	$data['remarks']=$this->input->post('remarks');
	    	$data['deal']=$this->input->post('deal');	    	   	
	    	$data['img_folder']="images/band/".str_replace(" ","",$vendor['name'])."/";	    	

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Band_model');
	    	  $result1 = $this->Band_model->set_data($data);
	    	  if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }
            }
            else
            {
               redirect('Site/admin/fail');
            }
         }
          else  
          {
          	$this->load->view('band_upload');
          }
        }

      else
         {
         	redirect('Site/admin');
         }   
	}

		
	public function photography_upload(){

     $this->form_validation->set_rules('uploadedimages[]','Upload image','callback_fileupload_check');
       
        if($this->input->post())
	    {	
	      if($this->form_validation->run())
	      {
	     	$data=array();
	        $vendor=array();

	    	$vendor['name']=$this->input->post('name');
	    	$vendor['category']=$this->input->post('category');
	    	$vendor['city']=$this->input->post('city');
	    	$vendor['address']=$this->input->post('address');
	    	$vendor['contact_person']=$this->input->post('contactp');
	    	$vendor['contact_no']=$this->input->post('contact');
	    	$vendor['email']=$this->input->post('email');
            $vendor['description']=$this->input->post('description');

	    	$data['traditional_p']=$this->input->post('tpp');
		    $data['candid_p']=$this->input->post('cpp');
		    $data['hd_v']=$this->input->post('hdv');
		    $data['dslr_v']=$this->input->post('dslrvd');
		    $data['album_cost']=$this->input->post('album_gloss');
		    $data['prewedding_cost']=$this->input->post('pre_wedding');
		    $data['basic_package']=$this->input->post('basic_package');
		    $data['remarks']=$this->input->post('remarks');
		    $data['deal']=$this->input->post('deal');	    	
            $data['img_folder']="photography/".str_replace(" ","",$vendor['name'])."/";

            $this->load->model('Vendor_model');
	    	$result = $this->Vendor_model->set_data($vendor);
            if($result)
            {
              $data['vendor_no']=$result;
              $this->load->model('Photography_model');
	    	  $result1 = $this->Photography_model->set_data($data);
	    	   if($result1)
	    	   {
	    	   	 redirect('Site/admin/success');
	    	   }

	    	   else
	    	   {
                  redirect('Site/admin/fail');
	    	   }

            }
            else
             {
                 $this->load->view('photography_upload');
             }
          }  
        }
         else
         {
         	redirect('Site/admin');
         }   		
		
	}	
	
	
	public function gallery($data="venue")
	{
        $query_result='';
        $this->load->model('Vendor_model');
        $query_result=$this->Vendor_model->load_all($data);
	
		$arg=array('query_result'=>$query_result,
					'type'=>$data);
		$this->load->view('default/header');
		$this->load->view('gallery',$arg);
		$this->load->view('default/footer');	
 	}

	public function vendorlist(){

        $query_result='';
        $this->load->model('Vendor_model');
        $query_result=$this->Vendor_model->load_vendor();

		$arg=array('query_result'=>$query_result);
		$this->load->view('vendorlist',$arg);	
	} 	
    /////////// end admin ///////////

    
 	public function search1(){
 		$this->load->view('default/header');
 		$this->load->view('search1');
 		$this->load->view('default/footer');
 	}
	
 	public function about(){
 		$this->load->view('default/header');
 		$this->load->view('aboutus.php');
 		$this->load->view('default/footer');
 	}

	public function newdelhi()
	{
		$this->load->view('delhi.php');
	}


	


//////////////////////////////////////////Search/////////////////////////////////////////////
public function search($data="")
{
	$this->load->view('search.php',$data);


}


public function contact($data="")
{
	$this->load->view('shaadi_contact.php',$data);
}


		
	public function venue_display($data)
	{
		$this->load->model('Venue_model');
		$result=$this->Venue_model->getvenue($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/venue/".$iname;
		$res=$this->_imgread($imgpath);
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('venue_profile',$data); 
		$this->load->view('default/footer');
	}	



	public function caterer_display($data)
	{
		$this->load->model('Caterer_model');
		$result=$this->Caterer_model->getcaterer($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/caterer/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('caterer_profile',$data);
		$this->load->view('default/footer'); 
	}	

	public function photography_display($data)
	{
		$this->load->model('Photography_model');
		$result=$this->Photography_model->getphotography($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/photography/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('photography_profile',$data);
		$this->load->view('default/footer'); 
	}


	public function gifts_display($data)
	{
		$this->load->model('Gifts_model');
		$result=$this->Gifts_model->getgifts($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/gifts/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('gifts_profile',$data); 
		$this->load->view('default/footer');
	}

	public function decor_display($data)
	{
		$this->load->model('Decor_model');
		$result=$this->Decor_model->getdecorator($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/decor/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('decor_profile',$data);
		$this->load->view('default/footer'); 
	}

	public function cards_display($data)
	{
		$this->load->model('Cards_model');
		$result=$this->Cards_model->getcards($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/cards/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('cards_profile',$data);
		$this->load->view('default/footer'); 
	}


	public function coins_display($data)
	{
		$this->load->model('Coins_model');
		$result=$this->Coins_model->getcoins($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/coins/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('coins_profile',$data);
		$this->load->view('default/footer'); 
	}

	
	public function band_display($data)
	{
		$this->load->model('Band_model');
		$result=$this->Band_model->getband($data);
		$iname=str_replace(" ","",$result->result()[0]->name);
		$imgpath="/band/".$iname;
		$res=$this->_imgread($imgpath);		
		$data=array('info'=>$result->result()[0],'image'=>$res);
		$this->load->view('default/header');
		$this->load->view('band_profile',$data);
		$this->load->view('default/footer'); 
	}		


	public function query()
	{
		$data =array(
        'Name' => $this->input->post('name1'),
        'Email' => $this->input->post('email1'),
        'Contact' => $this->input->post('phone1'),
        'Message' => $this->input->post('msg')
	    );
        
        $msg=$data['Name'].'<br><br>'.$data['Email'].'<br><br>'.$data['Contact'].'<br><br>'.$data['Message'];

	    $this->load->model('query_model');
	    $result = $this->query_model->insert_query($data);
        if($result)
        {
        	echo json_encode($result);
        	$this->_sendmail($data['Name'],$data['Email'],$msg);
        }
 
	}

///////////////////// code  file upload /////// /////// 
  private $_uploaded;
 

  // now the callback validation that deals with the upload of files
  public function fileupload_check()
  {
    $img=str_replace(" ","",$this->input->post('name'));
    $type=$this->input->post('category');

    if(!is_dir('./images/'.$type.'/'.$img))
     {
       mkdir('./images/'.$type.'/'.$img,0777,TRUE);
     }
    // we retrieve the number of files that were uploaded
    $number_of_files = sizeof($_FILES['uploadedimages']['tmp_name']);
 
    // considering that do_upload() accepts single files, we will have to do a small hack so that we can upload multiple files. For this we will have to keep the data of uploaded files in a variable, and redo the $_FILE.
    $files = $_FILES['uploadedimages'];
 
    // first make sure that there is no error in uploading the files
    for($i=0;$i<$number_of_files;$i++)
    {
      if($_FILES['uploadedimages']['error'][$i] != 0)
      {
        // save the error message and return false, the validation of uploaded files failed
        $this->form_validation->set_message('fileupload_check', 'Couldn\'t upload the file(s)');
        return FALSE;
      }
    }
    
    // we first load the upload library
    $this->load->library('upload');
    // next we pass the upload path for the images
    $config['upload_path'] = './images/'.$type.'/'.$img;
    // also, we make sure we allow only certain type of images
    $config['allowed_types'] = 'gif|jpg|png';

    $config['remove_spaces'] = TRUE ;
 
    // now, taking into account that there can be more than one file, for each file we will have to do the upload
    for ($i = 0; $i < $number_of_files; $i++)
    {
	
	  $temp=explode('.',$files['name'][$i]);
      $_FILES['uploadedimage']['name'] = "img".($i+1).".".$temp[1];
      $_FILES['uploadedimage']['type'] = $files['type'][$i];
      $_FILES['uploadedimage']['tmp_name'] = $files['tmp_name'][$i];
      $_FILES['uploadedimage']['error'] = $files['error'][$i];
      $_FILES['uploadedimage']['size'] = $files['size'][$i];
      
      //now we initialize the upload library
      $this->upload->initialize($config);
      if ($this->upload->do_upload('uploadedimage'))
      {
        $this->_uploaded[$i] = $this->upload->data();
      }
      else
      {
        $this->form_validation->set_message('fileupload_check', $this->upload->display_errors());
        return FALSE;
      }
    }
    return TRUE;
  }
     

	function _sendmail($name,$to,$msg)
	{
	    $this->load->library('email'); 
	    $this->email->from('pankaj.arora1994@gmail.com', $name);
	    $this->email->to($to);
	    $this->email->subject('You have new query from WebSite');
	    $this->email->message($msg);
	    if ($this->email->send())
	        return true;
	    else
	        return false;
	}

	
	
}
