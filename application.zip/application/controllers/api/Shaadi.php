<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';

class Shaadi extends REST_Controller{
   function __construct()
   {

   	parent::__construct();
      $this->load->library('email');
   	
   }	

  /* public function index_get()
   {
      $this->load->model('Vendor_model');
   	 $result=$this->Vendor_model->demo();
       $query=$result->result_array();
   	 if($query)
   	 {
   	 	$this->response($query,200);
   	 }
   	 else
   	 {
   	 	 $this->response(array('error' => 'Couldn\'t find any vendors'), 404);
   	 }
       
   }
   */

   public function gallery_get($data="venue")
   {
        $query_result='';
        $this->load->model('Vendor_model');
        $query_result=$this->Vendor_model->load_vendor($data);
        $query=$query_result->result_array();  
         if($query)
          {
            $this->response($query,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendors'),REST_Controller::HTTP_NOT_FOUND);
          }
   }
  
   public function venuedisplay_get($data)
   {
      $this->load->model('Venue_model');
      $result=$this->Venue_model->getvenue($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  

   public function catererdisplay_get($data)
   {
      $this->load->model('Caterer_model');
      $result=$this->Caterer_model->getcaterer($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  


   public function photographydisplay_get($data)
   {
      $this->load->model('Photography_model');
      $result=$this->Photography_model->getphotography($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  

   public function giftsdisplay_get($data)
   {
      $this->load->model('Gifts_model');
      $result=$this->Gifts_model->getgifts($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  

   public function decordisplay_get($data)
   {
      $this->load->model('Decor_model');
      $result=$this->Decor_model->getdecorator($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND );
          }
   }  

   public function cardsdisplay_get($data)
   {
      $this->load->model('Cards_model');
      $result=$this->Cards_model->getcards($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }     

   public function coinsdisplay_get($data)
   {
      $this->load->model('Coins_model');
      $result=$this->Coins_model->getcoins($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  

   public function banddisplay_get($data)
   {
      $this->load->model('Band_model');
      $result=$this->Band_model->getband($data);
      $row=$result->result_array(); 
         if($row)
          {
            $this->response($row,REST_Controller::HTTP_OK);
          }
          else
          {
             $this->response(array('error' => 'Couldn\'t find any vendor'),REST_Controller::HTTP_NOT_FOUND);
          }
   }  


   public function contact_post()
   {

      $name=$this->input->post('name');
      $to=$this->input->post('to');
      $msg=$this->input->post('msg');
      $result=$this->sendmail($name,$to,$msg);

      if($result)
       {
         $this->response(array('status' => 'Done'),REST_Controller::HTTP_CREATED);
       }
       else
       {
          $this->response(array('error' => 'Couldn\'t mail'),REST_Controller::HTTP_NOT_FOUND);
       }

   }


   public function sendmail($name,$to,$msg)
   { 
       $this->email->from('pankaj.arora1994@gmail.com', $name);
       $this->email->to($to);
       $this->email->subject('You have new query from WebSite');
       $this->email->message($msg);
       if ($this->email->send())
           return TRUE;
       else
           return FALSE;
   }



}