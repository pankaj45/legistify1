

  <section id="intro">
    <!--=== Slider ===-->
    <div class="tp-banner-container">
        <div class="tp-banner">
            <ul>
                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Memorable Shaadi">
                    <!-- MAIN IMAGE -->
                    <img src=" assets/img/sliders/bg.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="80"
                        data-speed="1000"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        We Are Here For You
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="170"
                        data-speed="1000"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are Wedding Management Company <br/>
                        providing key services for your weddings/events.
                    </div>

                    <!-- LAYER -->
                </li>
                <!-- END SLIDE -->

                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Memorable Shaadi">
                    <!-- MAIN IMAGE -->
                    <img src=" assets/img/sliders/bg1.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="100"
                        data-speed="1500"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        Includes 160+ Template Pages
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="190"
                        data-speed="1400"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are creative technology company providing <br/>
                        key digital services on web and mobile.
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="310"
                        data-speed="1600"
                        data-start="2800"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Learn More</a>
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Our Work</a>
                    </div>
                </li>
                <!-- END SLIDE -->

                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Memorable Shaadi">
                    <!-- MAIN IMAGE -->
                    <img src=" assets/img/sliders/bg2.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="100"
                        data-speed="1500"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        Over 12000+ Satisfied Users
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="190"
                        data-speed="1400"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are creative technology company providing <br/>
                        key digital services on web and mobile.
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="310"
                        data-speed="1600"
                        data-start="2800"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Learn More</a>
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Our Work</a>
                    </div>
                </li>
                <!-- END SLIDE -->
            </ul>        
        </div>
    </div>
    <!--=== End Slider ===--> 

        <div class="container-fluid" style="background:rgba(0,0,0,0.9); "> 
            <div class="col-sm-6 col-sm-offset-3 animated fadeInLeft">
                <div class="input-group" style="margin:10px;">
                    <input type="text" class="form-control" placeholder="Search your vendor" />
                    <span class="input-group-btn">
                        <button class="btn-u btn-u-md" type="button"><i class="fa fa-search"></i></button>
                    </span>                    
                </div>    
            </div>
        </div>  

    <div class="purchase">
        <div class="container">
            <div class="row">
                <div class="col-md-12 animated fadeInLeft">
                    <h2 class="text-danger text-center">Making those special moments extra-special, memorable and cherish able!!</h2>
                    <p >
We at Memorable Shaadi will provide a complete buffet of services so that you can worry less, enjoy the celebrations and spend more time with the to-be bride/groom. We have hand-picked our partners who can provide the best in class services including venues, decoration, catering, photography, entertainment and travel arrangement for you and your family.</p>
<br/>
<p>
In case you want us to help you with individual services, don’t hesitate just <strong>Call/Email Us</strong> and we’ll get it done.
<br/>
We are a wedding management company run by a highly professional team of engineers from IIT, Chartered Accounts and MBA’s from Top Business Schools. Driven by the same passion of making the ever so confusing, ad-hoc wedding industry simpler and organized.</p>
                </div>            
            </div>
        </div>
    </div> 

       
</section>
	 
  <section id="services">

    <div class="container content-sm">
        <div class="headline text-center"><h2>Our services</h2></div>
        
        <!-- Easy Blocks v1 -->                
        <div class="row high-rated margin-bottom-20">
            <!-- Easy Block -->                
            <div class="col-xs-12 col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Venues</div>                
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/venue.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/venue2.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/venue4.jpg">
                            </div>

                        </div>
                    </div>                    
                    <a class="btn-u btn-u-xs" href="Site/gallery/venue">View More</a>
                </div>  
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
            <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Catering</div>
                    <div id="carousel-example-generic-2" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-2" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-2" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-2" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/catering.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/catering1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/catering2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/caterer">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-xs-12 col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Photography</div>
                    <div id="carousel-example-generic-3" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-3" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-3" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-3" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/11.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/5.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/photography">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Gifts</div>
                    <div id="carousel-example-generic-4" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-4" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-4" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-4" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/entertainmnt.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/entertainmnt1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/entertainmnt2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/gifts">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
        </div>
        <!-- End Easy Blocks v1 -->                


        <!-- Easy Blocks v2 -->
        <div class="row">
            <!-- Easy Block -->                
            <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-default">Decorators</div>                
                    <div id="carousel-example-generic-5" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-5" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-5" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-5" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/13.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/12.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/1.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/decor">View More</a>
                </div>  
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
            <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Invitation Cards</div>
                    <div id="carousel-example-generic-6" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-6" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-6" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-6" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/6.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/7.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/8.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/cards">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Gold/Silver Coins</div>
                    <div id="carousel-example-generic-7" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-7" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-7" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-7" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/tent.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/tent1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/tent2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/coins">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-xs-12 col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Wedding Bands</div>
                    <div id="carousel-example-generic-8" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-8" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-8" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-8" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src=" assets/img/main/3.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/4.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src=" assets/img/main/9.jpg">
                            </div>                            
                        </div>
                    </div>
                    <a class="btn-u btn-u-xs" href="Site/gallery/band">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
        </div>
        <!-- End Easy Blocks v1 -->     
    </div>
    <!--=== End Content ===-->

      <!--testimonials-->
           <div class="container content-sm">        
            <div class="headline text-center "><h2>What people say about us</h2></div>
            <div class="testimonials-bs parallaxBg1">            
             <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div id="testimonials-4" class="carousel slide testimonials testimonials-v2 testimonials-bg-red">
                            <div class="carousel-inner">
                                <div class="item active">
                                    <p class="rounded-3x" >Dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpaid est praesentium..</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Jeremy Asigner 
                                            <em>Web Developer, Unify Theme.</em>
                                        </span>
                                    </div>
                                </div>
                                <div class="item">
                                    <p class="rounded-3x">Cras justo odio, dapibus ac facilisis into egestas. Dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupidinon..</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Bootstrap :) 
                                            <em>Java Developer, Htmlstream</em>
                                        </span>
                                    </div>
                                </div>
                                <div class="item">
                                    <p class="rounded-3x">Justo odioDignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique facilisis into egestas.</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Kate Davenport 
                                            <em>Web Designer, Google Inc.</em>
                                        </span>
                                    </div>                                
                                </div>

                            </div>
                            
                            <div class="carousel-arrow">
                                <a class="left carousel-control" href="#testimonials-4" data-slide="prev">
                                    <i class="fa fa-angle-left rounded-x"></i>
                                </a>
                                <a class="right carousel-control" href="#testimonials-4" data-slide="next">
                                    <i class="fa fa-angle-right rounded-x"></i>
                                </a>
                            </div>
                        </div> 
                    </div>     
                </div>
               </div>  
             </div>

   </section>
      
    <section id="venues">
      <div class="container content-sm">
        <div class="headline text-center"><h2>Venues</h2></div>
         <div class="row">
           <div class="col-xs-6 col-sm-3">
             <a href="Site/newdelhi">
             <img class="img-responsive img-circle" src="assets/img/team/5.png">
             <h3 class="text-center color-green">New Delhi</h3>
             </a>
           </div>
           <div class="col-xs-6 col-sm-3">
             <img class="img-responsive img-circle" src="assets/img/team/5.png">
             <h3 class="text-center color-green">Udaipur</h3>
           </div>
           <div class="col-xs-6 col-sm-3">
             <img class="img-responsive img-circle" src="assets/img/team/5.png">
             <h3 class="text-center color-green">Bangkok</h3>
           </div>
           <div class="col-xs-6 col-sm-3">
             <img class="img-responsive img-circle" src="assets/img/team/5.png">
             <h3 class="text-center color-green">Goa</h3>
           </div>                                 
         </div>
        </div>    
    </section>
     
      <section id="about">
        <div class="container content-sm">
          <div class="headline text-center"><h2>About Us</h2></div>
           <div class="row">
            <div class="col-md-12 margin-bottom-40">
              <p> In India marriage is a ceremony where two souls, two families and two worlds come together to become one. It’s a celebration to be remembered and cherished for life long. And that’s exactly what we aspire to do for you, we want you and your family to enjoy the journey and not worry about the Venue or catering or decoration or for that matter any logistical requirement that goes into making it memorable. The biggest worry for most of us, “budget”; let’s just say, you tell us the limit and we’ll deliver the best. That’s what we are here for.<br><br>

We at Memorable Shaadi will provide a complete buffet of services so that you can worry less, enjoy the celebrations and spend more time with the to-be bride/groom. We have hand-picked our partners who can provide the best in class services including venues, decoration, catering, photography, entertainment and travel arrangement for you and your family.<br><br>

In case you want us to help you with individual services, don’t hesitate just call us and we’ll get it done.<br><br>

We are a wedding management company run by a highly professional team of engineers from IIT, Chartered Accounts and MBA’s from Top Business Schools. Driven by the same passion of making the ever so confusing, ad-hoc wedding industry simpler and organized.</p>
            </div>
           </div>
        </div>
      

        <div class="container">
          <div class="headline text-center"><h2>Meet Our Team</h2></div>
            <div class="row team">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-v2">
                        <img class="img-responsive" src="assets/img/team/ujwal.jpg" alt="" />
                        <div class="inner-team">
                            <h3>Jack Anderson</h3>
                            <small class="color-green">CEO, Chief Officer</small>
                            <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                            <hr>    
                            <ul class="list-inline team-social">
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-v2">
                        <img class="img-responsive" src="assets/img/team/ujwal.jpg" alt="" />
                        <div class="inner-team">
                            <h3>Jack Anderson</h3>
                            <small class="color-green">CEO, Chief Officer</small>
                            <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                            <hr>    
                            <ul class="list-inline team-social">
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-v2">
                        <img class="img-responsive" src="assets/img/team/ujwal.jpg" alt="" />
                        <div class="inner-team">
                            <h3>Jack Anderson</h3>
                            <small class="color-green">CEO, Chief Officer</small>
                            <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                            <hr>    
                            <ul class="list-inline team-social">
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-v2">
                        <img class="img-responsive" src="assets/img/team/ujwal.jpg" alt="" />
                        <div class="inner-team">
                            <h3>Jack Anderson</h3>
                            <small class="color-green">CEO, Chief Officer</small>
                            <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                            <hr>    
                            <ul class="list-inline team-social">
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

           <a class="btn-u btn-u-sm pull-right" href="Site/about" style="margin-bottom:10px">View Our Complete Team</a> 
        </div><!--/team-->
    </div>
  </section>
    

    <section id="foot">
        <div class="container contacts-section content-sm margin-bottom-20">
          <div class="headline text-center"><h2>Contact Us</h2></div>
            <div class="row contacts-in">
                <div class="col-md-6 md-margin-bottom-40">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-home"></i><b> 27,Community Center,Naraina Industrial Area,New Delhi-110028 </b></li>
                        <li><i class="fa fa-phone"></i><b> 011-65549945</b></li>
                        <li><i class="fa fa-envelope"></i><a href="contact@memorableshaadi.com" ><b>contact@memorableshaadi.com</b></a></li>
                        <li><i class="fa fa-globe"></i> <a href="http://memorableshaadi.com"><b>www.memorableshaadi.com</b></a></li>
                    </ul>
                </div>

                <div class="col-md-6">
                    <form class="sky-form contact-style" method="post">
                        <fieldset>
                            <label><b>Name</b><span class="color-red">*</span></label>
                            <div class="row">
                                <div class="col-md-7 margin-bottom-20 col-md-offset-0">
                                    <div>
                                        <input type="text" name="name" id="name" class="form-control" required>
                                    </div>
                                </div>                
                            </div>

                            <label><b>Phone No.</b><span class="color-red">*</span></label>
                            <div class="row">
                                <div class="col-md-7 margin-bottom-20 col-md-offset-0">
                                    <div>
                                        <input type="text" name="phone" id="phone" class="form-control" required>
                                    </div>
                                </div>                
                            </div>

                            <label><b>Email</b><span class="color-red">*</span></label>
                            <div class="row">
                                <div class="col-md-7 margin-bottom-20 col-md-offset-0">
                                    <div>
                                        <input type="text" name="email" id="email" class="form-control" required>
                                    </div>
                                </div>                
                            </div>
                            
                            <label><b>Message</b><span class="color-red">*</span></label>
                            <div class="row">
                                <div class="col-md-11 margin-bottom-20 col-md-offset-0">
                                    <div>
                                        <textarea rows="8" name="message" id="message" class="form-control" required></textarea>
                                    </div>
                                </div>                
                            </div>
                            
                            <p><button type="submit" class="btn-u btn-u-sm" id="submit">Send Message</button></p>
                        </fieldset>
                    </form> 
                      
                            <div class="form-group" id="result" style="display:none;">
                                 Thank you for contacting us. You will receive info shortly.
                            </div>                      
                </div>
            </div>            
        </div>
    </section> 
   
