<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
    <base href="<?php echo base_url(); ?>"></base>
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href=" assets/css/headers/header-v6.css">    
    <link rel="stylesheet" href=" assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="assets/plugins/animate.css">
    <link rel="stylesheet" href="assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href="assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href="assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href="assets/plugins/image-hover/css/img-hover.css">
    <link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css">
    <link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css">
    <link rel="stylesheet" href="assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href="assets/css/custom.css">
   
</head>	

<body class="header-fixed header-fixed-space" data-spy="scroll" data-target=".onefixed">    

<div class="wrapper">
    <div class="header-v6 header-classic-white header-sticky">

        <!-- Navbar -->
        <nav class="navbar navbar-default mega-menu onefixed" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img id="logo-header" class="hidden-xs" src=" assets/img/logo2.png" alt="Logo">
                        <img id="logo-header" class="visible-xs" src=" assets/img/logo-xs.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#intro" class="page-scroll">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#services" class="page-scroll" >
                                    Our Services
                                </a>
                            </li>                    
                            
                            <li>
                                <a href="#venues" class="page-scroll" >
                                    Venues
                                </a>
                            </li>

                            <li>
                                <a href="#" class="page-scroll blink_text" style="color:red">
                                    Plan your Event Now
                                </a> 
                            </li>  

                            <li>
                                <a href="#about" class="page-scroll">
                                    About Us
                                </a>
                            </li>                    
                           

                            <li>
                                <a href="#foot" class="page-scroll">
                                    Contact Us
                                </a>
                            </li>        

                            <li>
                                <a href="#" class="page-scroll">
                                    Blog
                                </a>
                            </li>                         


                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </nav>            
        <!-- End Navbar -->
    </div>
    
    <div class="col-md-6 col-md-offset-3">


                    <div class="panel panel-red margin-bottom-40">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="fa fa-tasks"></i>Gifts-<?php if(isset($name)) echo $name ; else echo set_value('name');?> </h3>
                        </div>
                        <div class="panel-body">                                                      
                            <form class="margin-bottom-40" method="post" action="Site/gifts_upload" enctype="multipart/form-data" role="form"> 
                              <input type="hidden" name="name" value="<?php if(isset($name)) echo $name ; else echo set_value('name'); ?>">
                              <input type="hidden" name="category" value="<?php if(isset($category)) echo $category ; else echo set_value('category'); ?>">
                              <input type="hidden" name="city" value="<?php if(isset($city)) echo $city ; else echo set_value('city'); ?>">
                              <input type="hidden" name="address" value="<?php if(isset($address)) echo $address ; else echo set_value('address'); ?>">
                              <input type="hidden" name="location" value="<?php if(isset($location)) echo $location ; else echo set_value('location'); ?>">
                              <input type="hidden" name="contactp" value="<?php if(isset($contactp)) echo $contactp ; else echo set_value('contactp'); ?>">
                              <input type="hidden" name="contact" value="<?php if(isset($contact)) echo $contact ; else echo set_value('contact'); ?>">
                              <input type="hidden" name="email" value="<?php if(isset($email)) echo $email ; else echo set_value('email'); ?>">
                              <input type="hidden" name="description" value="<?php if(isset($description)) echo $description ; else echo set_value('description'); ?>">
                              
                                <div class="form-group">
                                    <label for="gift_details">Gift Details</label>
                                    <textarea rows="5" name="gift_details" class="form-control" value="<?php echo set_value('gift_details'); ?>" required></textarea>
                                </div>


                                <div class="form-group">
                                    <label for="gift_price">Gift Prices Starts From</label>
                                    <input type="text" name="gift_price" value="<?php echo set_value('gift_price'); ?>" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="remarks">Remarks</label>
                                    <textarea rows="5" name="remarks" class="form-control" value="<?php echo set_value('remarks'); ?>" ></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="deal">Deal</label>
                                    <textarea rows="5" name="deal" class="form-control" value="<?php echo set_value('deal'); ?>" required></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="uploadedimages[]">Upload Pictures</label>
                                    <input type="file" name="uploadedimages[]" class="form-control" multiple required>
                                </div>                                

                                  <button type="submit" class="btn-u btn-u-red">Submit</button>
                                 
                            </form>
                        </div>
                    </div>

    </div>   

    





</div><!--/wrapper-->

<!-- JS Global Compulsory -->           
<script type="text/javascript" src=" assets/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery/jquery-migrate.min.js"></script>
<script type="text/javascript" src=" assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script type="text/javascript" src=" assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src=" assets/plugins/smoothScroll.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.easing.min.js"></script>
<script type="text/javascript" src=" assets/plugins/jquery.parallax.js"></script>
<script type="text/javascript" src=" assets/plugins/flexslider/jquery.flexslider-min.js"></script>
<script type="text/javascript" src=" assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src=" assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/touch.js"></script>
<script type="text/javascript" src=" assets/plugins/image-hover/js/modernizr.js"></script>
<!-- JS Customization -->
<script type="text/javascript" src=" assets/js/custom.js"></script>
<!-- JS Page Level -->           
<script type="text/javascript" src=" assets/js/app.js"></script>
<script type="text/javascript" src=" assets/js/plugins/fancy-box.js"></script>
<script type="text/javascript" src=" assets/js/plugins/revolution-slider.js"></script>

<script src="assets/plugins/scroll/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll/js/scrolling-nav.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        FancyBox.initFancybox();
        RevolutionSlider.initRSfullWidth();
    });
</script>

</body>
</html>