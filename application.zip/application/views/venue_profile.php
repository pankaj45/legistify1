<?php
$i=1;
$name=str_replace(" ","",$info->name);
$img="images/venue/".$name;
?>

  <div class="container">
     <div class="row">
         <div class="col-sm-8">
          <div class="profile-body">
            <div class="shadow-wrapper">
            <div class="profile-bio tag-box tag-box-v2 box-shadow shadow-effect-1">
                <div class="row">
                    <div class="col-sm-5">
                        <img class="img-responsive md-margin-bottom-10" src="<?php echo $img.'/'.$image[0] ; ?>" alt="">
                    </div>
                    <div class="col-sm-7">
                        <h2><?php echo $info->name?></h2>
                        <strong>Venue</strong>
                        <hr>
                        <p><?php echo $info->description; echo $info->description; ?></p>
                        <br/>
                        <p><b>Exclusive prices Only for memorable shaadi customers.</b></p>
                        <br/>
                        <p><b>Contact us Now.</b></p>
                    </div>
                </div>    
            </div>
            </div>
           </div>
          </div>

         <div class="col-xs-12 col-sm-4">
            <div class="panel panel-red margin-bottom-10">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Request Memorable Shaadi Special price</h3>
                </div>        
                <div class="panel-body"> 
                <form class="margin-bottom-10" method="post" role="form">
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" placeholder="Enter Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" id="email" placeholder="Enter Email" required>
                    </div>                    
                    <div class="form-group">
                        <input type="text" class="form-control" id="phone" placeholder="Enter Phone" required>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" id="message" placeholder="Enter message" required></textarea>
                    </div>
                    <button type="submit" class="btn-u btn-u-red" id="submit">Submit</button>
                </form>   
                    <div class="form-group" id="result" style="display:none;">
                         Thank you for contacting us. You will receive info shortly.
                    </div>                          
                </div>
            </div> 
         </div>
     </div>

      <div class="row">
       <div class="col xs-12 col-sm-8">  
         <div class="shadow-wrapper">
            <div class="tag-box tag-box-v2 box-shadow shadow-effect-1">
                <h2>PHOTOS</h2>
                 <div class="row  margin-bottom-30 margin-top-20">
                    <?php  
                    foreach ($image as $path) {
                        echo '  
                         <div class="col-sm-4 sm-margin-bottom-30">
                            <a href="'.$img.'/'.$path.'" rel="gallery1" class="fancybox img-hover-v1" title="'.$path.'">
                                <span><img class="img-responsive" src="'.$img.'/'.$path.'" alt=""></span>
                            </a>
                         </div>';

                         if(($i%3)==0)
                         {
                            echo '</div><div class="row margin-top-20">';
                         }
                        $i++;
                    } 
                    ?> 
                 </div>   
                           
            </div>
        </div>
       </div> 
      </div>

      <div class="row">
       <div class="col-xs-12 col-sm-8">  
         <div class="shadow-wrapper">
            <div class="tag-box tag-box-v2 box-shadow shadow-effect-1">
              <h2>ABOUT US</h2>
               <div class="row">
                 <div class="col-xs-4 col-sm-4">
                   <h5><b>Name:</b></h5>
                   <h5><b>Type:</b></h5>
                   <h5><b>Address:</b></h5>
                   <h5><b>Minimum Capacity:</b></h5>
                   <h5><b>Maximum Capacity:</b></h5>
                   <h5><b>Outside Catering Allowed?</b></h5>
                   <h5><b>Outside Decoration Allowed?</b></h5> 
                 </div>
                 <div class="col-xs-8 col-sm-8 ">
                   <h5><?php echo $info->name ; ?></h5>
                   <h5><?php echo $info->type ; ?></h5>
                   <h5><?php echo $info->address ; ?></h5>
                   <h5><?php echo $info->capacity_min ; ?></h5>
                   <h5><?php echo $info->capacity_max ; ?></h5>
                   <h5><?php echo $info->outside_catering ; ?></h5>
                   <h5><?php echo $info->outside_decor ; ?></h5>
                 </div>                 
                </div> 
            </div>          
        </div>
       </div>        
      </div>

    </div>
   
