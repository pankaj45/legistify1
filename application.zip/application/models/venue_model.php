<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Venue_model extends CI_Model {


function set_data($data)
  {
  	if($this->db->insert('venues',$data))
    {
      return true;
    }
    else
    {
      return false;
    }
  } 


function search($string)
{
	$query="SELECT `name` FROM `venues` WHERE  MATCH (`tags`) AGAINST ('$string' IN BOOLEAN MODE) LIMIT  	10";
	$result=$this->db->query($query);
	return $result;
	
}

function getvenue($data)
{	$query="SELECT * FROM `vendor` INNER JOIN `venues` ON `vendor`.vendor_no = `venues`.vendor_no AND `vendor`.`category`='venue' AND `venues`.`vendor_no`=$data ";

	return $this->db->query($query);

}




}