<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> 
<html lang="en"> <!--<![endif]-->  
<head>
   <!-- <base href="<?php echo base_url(); ?>"></base> -->
    <title>Memorable Shaadi</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Web Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    <!-- CSS Header and Footer -->
    <link rel="stylesheet" href="../assets/css/headers/header-v1.css">
    <link rel="stylesheet" href="../assets/css/footers/footer-v1.css">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="../assets/plugins/animate.css">
    <link rel="stylesheet" href="../assets/plugins/line-icons/line-icons.css">
    <link rel="stylesheet" href="../assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/plugins/bxslider/jquery.bxslider.css">
    <link rel="stylesheet" href="../assets/plugins/fancybox/source/jquery.fancybox.css"> 
    <link rel="stylesheet" href="../assets/plugins/revolution-slider/rs-plugin/css/settings.css" type="text/css" media="screen">
    <link rel="stylesheet" href="../assets/plugins/image-hover/css/img-hover.css">

    <link rel="stylesheet" href="../assets/css/theme-colors/red.css"/>
    <!-- CSS Customization -->
    <link rel="stylesheet" href="../assets/css/custom.css">

<style type="text/css">
.modal-body {
    max-height: calc(100vh - 212px);
    overflow-y: auto;
}	
input[type=checkbox] {
    vertical-align: -2px;
}
</style>    
</head>	

<body>    

<div class="wrapper">
    <div class="header-v1">
        <!-- Topbar -->
        <div class="topbar-v1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-inline top-v1-contacts">
                            <li>
                                <i class="fa fa-envelope"></i><a href="mailto:info@htmlstream.com">contact@memorable.com</a>
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>011:65656565
                            </li>
                        </ul>
                    </div>

<!--                     <div class="col-md-6">
                        <ul class="list-inline top-v1-data">
                            <li><a href="#"><i class="fa fa-home"></i></a></li>
                            <li><a href="#"><i class="fa fa-globe"></i></a></li>
                            <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            <li><a href="#">Quicklinks</a></li>
                            <li><a href="#">My Account</a></li>
                        </ul>
                    </div> -->
                </div>        
            </div>
        </div>
        <!-- End Topbar -->
    
        <!-- Navbar -->
        <div class="navbar navbar-default mega-menu" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img id="logo-header" src="../assets/img/logo1.png" alt="Logo">
                    </a>
                </div>

                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <ul class="nav navbar-nav">
                            <li>
                                <a href="#">
                                    Home
                                </a>

                            </li>

                            <li>
                                <a href="#">
                                    About Us
                                </a>
                            </li>                    

                            <li>
                                <a href="Site/contact">
                                    Contact Us
                                </a>
                            </li>                    

                            <li>
                                <a href="#">
                                    Gallery
                                </a>
                            </li>        

                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>                         

                            
                            <!-- Search Block -->
                            <li>
                                <i class="search fa fa-search search-btn"></i>
                                <div class="search-open">
                                    <div class="input-group animated fadeInDown">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <span class="input-group-btn">
                                            <button class="btn-u" type="button">Go</button>
                                        </span>
                                    </div>
                                </div>    
                            </li>
                            <!-- End Search Block -->
                    </ul>                    
                </div><!--/navbar-collapse-->
            </div>    
        </div>            
        <!-- End Navbar -->
    </div>
    <!--=== Slider ===-->
    <div class="tp-banner-container">
        <div class="tp-banner">
            <ul>
                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Title 1">
                    <!-- MAIN IMAGE -->
                    <img src="../assets/img/sliders/bg.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="80"
                        data-speed="1000"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        We Are Here For You
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="170"
                        data-speed="1000"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are Wedding Management Company <br/>
                        providing key services for your weddings/events.
                    </div>

                    <!-- LAYER -->
                </li>
                <!-- END SLIDE -->

                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Title 2">
                    <!-- MAIN IMAGE -->
                    <img src="../assets/img/sliders/bg1.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="100"
                        data-speed="1500"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        Includes 160+ Template Pages
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="190"
                        data-speed="1400"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are creative technology company providing <br/>
                        key digital services on web and mobile.
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="310"
                        data-speed="1600"
                        data-start="2800"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Learn More</a>
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Our Work</a>
                    </div>
                </li>
                <!-- END SLIDE -->

                <!-- SLIDE -->
                <li class="revolution-mch-1" data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Title 3">
                    <!-- MAIN IMAGE -->
                    <img src="../assets/img/sliders/bg2.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">

                    <div class="tp-caption revolution-ch1 sft start"
                        data-x="center"
                        data-hoffset="0"
                        data-y="100"
                        data-speed="1500"
                        data-start="500"
                        data-easing="Back.easeInOut"
                        data-endeasing="Power1.easeIn"                        
                        data-endspeed="300">
                        Over 12000+ Satisfied Users
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption revolution-ch2 sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="190"
                        data-speed="1400"
                        data-start="2000"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        We are creative technology company providing <br/>
                        key digital services on web and mobile.
                    </div>

                    <!-- LAYER -->
                    <div class="tp-caption sft"
                        data-x="center"
                        data-hoffset="0"
                        data-y="310"
                        data-speed="1600"
                        data-start="2800"
                        data-easing="Power4.easeOut"
                        data-endspeed="300"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="off"
                        style="z-index: 6">
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Learn More</a>
                        <a href="#" class="btn-u btn-brd btn-brd-hover btn-u-light">Our Work</a>
                    </div>
                </li>
                <!-- END SLIDE -->
            </ul>
            <div class="tp-bannertimer tp-bottom"></div>            
        </div>
    </div>
    <!--=== End Slider ===-->

    <div class="purchase">
        <div class="container">
            <div class="row">
                <div class="col-md-12 animated fadeInLeft">
                    <h2 class="text-danger text-center">Making those special moments extra-special, memorable and cherish able!!</h2>
                    <p >
We at Memorable Shaadi will provide a complete buffet of services so that you can worry less, enjoy the celebrations and spend more time with the to-be bride/groom. We have hand-picked our partners who can provide the best in class services including venues, decoration, catering, photography, entertainment and travel arrangement for you and your family.</p>
<br/>
<p>
In case you want us to help you with individual services, don’t hesitate just <strong>Call/Email Us</strong> and we’ll get it done.
<br/>
We are a wedding management company run by a highly professional team of engineers from IIT, Chartered Accounts and MBA’s from Top Business Schools. Driven by the same passion of making the ever so confusing, ad-hoc wedding industry simpler and organized.</p>
                </div>            
            </div>
        </div>
    </div>
    <!--=== Content ===-->
    <br/>
    <div class="container">
      <div class="headline text-center margin-bottom-35"><h2>Events </h2></div>     
       <div class="row">
        <div class="col">
         <h4 class="text-center">Whether its a Birthday Party or Corporate Meetings,We provide you vendors for each and every need and Obviously at Best Price</h4>
        </div>
       </div>
       
	   <div class="row">
	     <div class="col-xs-12 col-sm-6 col-md-3">
	      <img class="img-circle popovers" src="../assets/img/team/rokka.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	      <div class="col-sm-10 col-md-10 col-md-offset-2">
	      <h3 class="text-danger">Rokka</h3>
	      </div>
	     </div>

	      <div class="col-xs-12 col-sm-6 col-md-3">
	       <img class="img-circle popovers" src="../assets/img/team/engagement.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	        <div class="col-sm-10 col-md-11 col-md-offset-1">
	         <h3 class="text-danger">Engagement</h3>
	        </div> 
	      </div>

	      <div class="col-xs-12 col-sm-6 col-md-3">
	       <img class="img-circle popovers" src="../assets/img/team/bachelors_party.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	        <div class="col-sm-10 col-md-11 col-md-offset-1"> 
	         <h3 class="text-danger">Bachelor's Party</h3>
	        </div> 
	      </div>

	      <div class="col-xs-12 col-sm-6 col-md-3">
	       <img class="img-circle popovers" src="../assets/img/team/mehendi.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	        <div class="col-sm-10 col-md-10 col-md-offset-2">
	         <h3 class="text-danger">Mehndi</h3>
	        </div>
	      </div>
	    </div> 

	   <div class="row">
	     <div class="col-xs-12 col-sm-6 col-md-3 col-md-offset-1">
	      <img class="img-circle popovers" src="../assets/img/team/reception.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	       <div class="col-md-10 col-md-offset-2">
	        <h3 class="text-danger">Reception</h3>
	       </div>  
	     </div>

	      <div class="col-xs-12 col-sm-6 col-md-3">
	       <img class="img-circle popovers" src="../assets/img/team/wedding_2day.jpg" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	        <div class="col-md-11 col-md-offset-1">
	         <h3 class="text-danger">Wedding Day</h3>
	        </div> 
	      </div>

	      <div class="col-xs-12 col-sm-6 col-md-3">
	       <img class="img-circle popovers" src="../assets/img/team/bday3.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
	        <div class="col-md-11 col-md-offset-1">
	         <h3 class="text-danger">Birthday Parties</h3>
	        </div>  
	      </div>
	    </div>      

        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-3 col-md-offset-4">
           <img class="img-circle popovers" src="../assets/img/team/corporate3.png" data-toggle="popover" data-placement="top" data-trigger="hover" data-html="true" data-content="<p class='text-danger bg-warning'>Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>"></img>
            <div class="col-md-11 col-md-offset-1">
             <h3 class="text-danger">Corporate Parties</h3>
            </div>  
          </div> 
        </div>               

	</div>  
	 


    <div class="container content">
        <div class="headline text-center margin-bottom-35"><h2>Our services</h2></div>
        
        <!-- Easy Blocks v1 -->                
        <div class="row high-rated margin-bottom-20">
            <!-- Easy Block -->                
            <div class="col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Venues</div>                
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/venue.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/venue2.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/venue4.jpg">
                            </div>

                        </div>
                    </div>                    
                    <a class="btn-u btn-u-sm" href="#">View More</a>
                </div>  
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
            <div class="col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Catering</div>
                    <div id="carousel-example-generic-2" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-2" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-2" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-2" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/catering.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/catering1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/catering2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Photography</div>
                    <div id="carousel-example-generic-3" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-3" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-3" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-3" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/11.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/5.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Entertainment</div>
                    <div id="carousel-example-generic-4" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-4" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-4" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-4" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/entertainmnt.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/entertainmnt1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/entertainmnt2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
        </div>
        <!-- End Easy Blocks v1 -->                

        <div class="clearfix margin-bottom-20"><hr></div>

        <!-- Easy Blocks v2 -->
        <div class="row">
            <!-- Easy Block -->                
            <div class="col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-default">Decoration</div>                
                    <div id="carousel-example-generic-5" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-5" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-5" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-5" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/13.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/12.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/1.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>
                </div>  
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
            <div class="col-sm-6 col-md-3 md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Invitation Cards</div>
                    <div id="carousel-example-generic-6" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-6" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-6" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-6" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/6.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/7.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/8.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-sm-6 col-md-3  md-margin-bottom-40">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Tent Vendors</div>
                    <div id="carousel-example-generic-7" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-7" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-7" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-7" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/tent.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/tent1.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/tent2.jpg">
                            </div>
                        </div>
                    </div>
                    <a class="btn-u btn-u-sm" href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
            
            <!-- Easy Block -->
           <div class="col-sm-6 col-md-3 md-margin-bottom-100">
                <div class="easy-block-v1">
                    <div class="easy-block-v1-badge rgba-red">Bandwala</div>
                    <div id="carousel-example-generic-8" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="rounded-x active" data-target="#carousel-example-generic-8" data-slide-to="0"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-8" data-slide-to="1"></li>
                            <li class="rounded-x" data-target="#carousel-example-generic-8" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img alt="" src="../assets/img/main/3.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/4.jpg">
                            </div>
                            <div class="item">
                                <img alt="" src="../assets/img/main/9.jpg">
                            </div>                            
                        </div>
                    </div>
                    <a href="#">View More</a>                                       
                </div>
            </div>
            <!-- End Easy Block -->
        </div>
        <!-- End Easy Blocks v1 -->     
    </div>
    <!--=== End Content ===-->
      <!--testimonials-->
           <div class="container">        
            <div class="headline text-center "><h2>What people say about us</h2></div>
			<div class="testimonials-bs bg-image-v2 parallaxBg1 margin-bottom-60">            
             <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div id="testimonials-4" class="carousel slide testimonials testimonials-v2 testimonials-bg-red">
                            <div class="carousel-inner">
                                <div class="item active">
                                    <p class="rounded-3x" >Dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpaid est praesentium..</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Jeremy Asigner 
                                            <em>Web Developer, Unify Theme.</em>
                                        </span>
                                    </div>
                                </div>
                                <div class="item">
                                    <p class="rounded-3x">Cras justo odio, dapibus ac facilisis into egestas. Dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupidinon..</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Bootstrap :) 
                                            <em>Java Developer, Htmlstream</em>
                                        </span>
                                    </div>
                                </div>
                                <div class="item">
                                    <p class="rounded-3x">Justo odioDignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique facilisis into egestas.</p>
                                    <div class="testimonial-info">
                                        <span class="testimonial-author">
                                            Kate Davenport 
                                            <em>Web Designer, Google Inc.</em>
                                        </span>
                                    </div>                                
                                </div>

                            </div>
                            
                            <div class="carousel-arrow">
                                <a class="left carousel-control" href="#testimonials-4" data-slide="prev">
                                    <i class="fa fa-angle-left rounded-x"></i>
                                </a>
                                <a class="right carousel-control" href="#testimonials-4" data-slide="next">
                                    <i class="fa fa-angle-right rounded-x"></i>
                                </a>
                            </div>
                        </div> 
                    </div>     
                </div>
               </div>  
             </div>

<div class="modal fade" id="mymodal" role="dialog">
 <div class="modal-dialog">

  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4>Request a Quote</h4> 
   </div>

  <div class="modal-body" style="padding:20px 50px;">
   <form role="form"> 
    <div class="form-group">   
      <label for="name">Name</label>
      <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" />
    </div>

    <div class="form-group">   
      <label for="contact">Contact No.</label>
      <input type="text" name="contact" class="form-control" id="contact" placeholder="Enter Contact No." >
    </div>    

    <label for="event">Events</label>

    <div class="radio">
     <label><input type="radio" name="event">Birthday Party</label>
    </div> 

    <div class="radio">
     <label><input type="radio" name="event">Wedding</label>
    </div> 


    <div class="radio">
     <label><input type="radio" name="event">Corporate Event</label>
    </div> 

    <div class="form-group">   
      <label for="city">City</label>
      <input type="text" name="city" class="form-control" id="city" placeholder="Enter city" >
    </div>      

    <div class="form-group">   
      <label for="date">Date</label>
      <input type="text" name="date" class="form-control" id="date" placeholder="dd/mm/yy" >
    </div>

    <div class="form-group">   
      <label for="capacity">Capacity</label>
      <input type="text" name="capacity" class="form-control" id="capacity" placeholder="Enter capacity" >
    </div>

    <div class="form-group">   
      <label for="budget">Budget</label>
      <input type="text" name="budget" class="form-control" id="budget" placeholder="Enter Budget" >
    </div>    
     

    <label>Services</label>
    <br/> 
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox1" value="venue">Catering
	</label>
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox2" value="catering">Venue
	</label>
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox3" value="photo">Photography
	</label>   
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox4" value="decor">Decoration
	</label>
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox5" value="entertain">Logistics
	</label>
	<br/>
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox5" value="entertain">Logistic
	</label>	
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox6" value="logistic">Cards
	</label> 	
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox7" value="cards">Band wala
	</label>
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox8" value="band">Tent vendor
	</label>	
	<label class="checkbox-inline">
	  <input type="checkbox" name="services[]" id="inlineCheckbox9" value="tent">Entertainment
	</label>
  </div>

  <div class="modal-footer">
   <button type="submit" class="btn btn-default btn-default pull-right" >Submit</button> 
  </div>
</form> 
 </div>
</div>
</div>


    <!--=== Footer Version 1 ===-->
    <div class="footer-v1">
        <div class="footer">

        </div><!--/footer-->

        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">                     
                        <p>
                            2015 &copy; All Rights Reserved.
                           <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
                        </p>
                    </div>

                    <!-- Social Links -->
                    <div class="col-md-6">
                        <ul class="footer-socials list-inline">
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Skype">
                                    <i class="fa fa-skype"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Linkedin">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Pinterest">
                                    <i class="fa fa-pinterest"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Dribbble">
                                    <i class="fa fa-dribbble"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- End Social Links -->
                </div>
            </div> 
        </div><!--/copyright-->
    </div>     
    <!--=== End Footer Version 1 ===-->
</div><!--/wrapper-->

<!-- JS Global Compulsory -->			
<script type="text/javascript" src="../assets/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="../assets/plugins/jquery/jquery-migrate.min.js"></script>
<script type="text/javascript" src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script type="text/javascript" src="../assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src="../assets/plugins/smoothScroll.js"></script>
<script type="text/javascript" src="../assets/plugins/jquery.parallax.js"></script>
<script type="text/javascript" src="../assets/plugins/flexslider/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="../assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="../assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="../assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/plugins/image-hover/js/touch.js"></script>
<script type="text/javascript" src="../assets/plugins/image-hover/js/modernizr.js"></script>
<!-- JS Customization -->
<script type="text/javascript" src="../assets/js/custom.js"></script>
<!-- JS Page Level -->           
<script type="text/javascript" src="../assets/js/app.js"></script>
<script type="text/javascript" src="../assets/js/plugins/fancy-box.js"></script>
<script type="text/javascript" src="../assets/js/plugins/revolution-slider.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
      	App.init();
        FancyBox.initFancybox();
        RevolutionSlider.initRSfullWidth();
    });
</script>

<!--[if lt IE 9]>
    <script src="assets/plugins/respond.js"></script>
    <script src="assets/plugins/html5shiv.js"></script>
    <script src="assets/plugins/placeholder-IE-fixes.js"></script>
<![endif]-->

</body>
</html>	