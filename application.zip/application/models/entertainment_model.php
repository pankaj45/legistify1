<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class entertainment_model extends CI_Model {
	public function getlist($data)
		{
			//$m=$data['menu'];
			//$t=$data['type'];
			
		//$t=$data['type'];
			$budget_range=$data['budget'];
			
			
			$query="SELECT  `name` , `s_no` FROM `vendor` WHERE`type`='entertainment' AND `starting_price` BETWEEN  $budget_range";
			$result=$this->db->query($query);
			return $result;
		}

function getentertainment($data)
{	$query="SELECT * FROM `vendor` INNER JOIN `entertainment` WHERE `vendor`.vendor_no = `entertainment`.vendor_no AND `vendor`.`table_name`='entertainment' AND `entertainment`.`vendor_no`=$data ";

	return $this->db->query($query);

}

}